# Secure Vision Grid Solutions Website

A responsive one-page business website for Secure Vision Grid Solutions.

## Files
- `index.html` — website content
- `style.css` — responsive design
- `script.js` — mobile menu and year
- `images/services-poster.jpg` — supplied business poster

## Publish on GitHub Pages
1. Create a new GitHub repository, e.g. `secure-vision-grid`.
2. Upload all files and the `images` folder.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will provide the live website URL.

## Before publishing
- Replace/add real project photos in `images/`.
- Confirm the two phone numbers.
- Add your business email if you want one.
- Add a custom domain later if desired.

## Contact numbers used
- 6395987004
- 7565884003

Service area shown: Greater Noida, Noida, Ghaziabad and Delhi NCR.
